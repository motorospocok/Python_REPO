#This python program parse the recommended paramter set xlsx file
#and generates mos file for setup
#Addtional file MoClass_trans.txt requires where the accurate Mo object must be given

from openpyxl import load_workbook
import re
wb = load_workbook(filename = 'ESS1.xlsx')
ws = wb['Recommended Parameter Settings']

def obtain_maxrange(): #this function obtain the number of moClass range in the Excel
    for i in range(2,160): #it must be a high number
        alma = ws.cell(i,1).value
        if alma == None: #if the cell moclass is empty then end of the list is ended
            maxmax = i
            print(maxmax)
            return(maxmax)
            break
    maxmax = i
    return(maxmax)

def print_excel(maxmax):

    for i in range (2,maxmax):
        f = open("result.mos", "a")
        moClass = ws.cell(i,1).value
        moClass2 = moClass_translation(moClass) #calling MoClass translation function
        moAttribute = ws.cell(i,2).value
        match = bool(re.search(r'\.',moAttribute))
        if match:
            moAttribute = moAttribute_check(moAttribute)
        else:
            moAttribute = moAttribute + ' '
        moValue = ws.cell(i, 9).value
        to_write = 'set ' + moClass2 + ' ' + moAttribute + moValue + '\r'
        print(moClass2,moAttribute,moValue)
        f.write(to_write)
        f.close()

def moAttribute_check(moAttribute2):
    txt = moAttribute2.split('.')
    moAttribute2 = txt[0] + ' ' + txt[1] + '='
    return(moAttribute2)

def moClass_translation(moClass1): #this function transalte the moClass object to concrete Mo instance
    datafile = open('MoClass_trans.txt','r')
    for line in datafile:
        if moClass1 in line:
            return(line.strip()) #remove new line character from the end of the line
            break
    return(moClass1)

zalma = obtain_maxrange()
print(zalma)
print_excel(zalma)